# Sistema de Votação A Fazenda 2026

Projeto React + Vite para a AV2 de DIAW. Mantém os arquivos auxiliares fornecidos na prova e implementa as páginas e componentes solicitados.

## Como executar

1. Instale o [Node.js](https://nodejs.org/) se ainda não estiver instalado.
2. Abra um terminal na pasta `VotacaoFazenda`.
3. Execute `npm install`.
4. Execute `npm run dev`.
5. Abra o endereço indicado no terminal, normalmente `http://localhost:5173/`.

Para validar a compilação de produção, execute `npm run build`.

## Arquivos implementados

- `src/components/ParticipanteCard.jsx`: card reutilizável para participantes da roça e demais peões.
- `src/pages/Votacao.jsx`: registro de votos, confirmação do último voto e grades de participantes.
- `src/pages/Resultado.jsx`: total, percentuais, placar ordenado e reinicialização com confirmação.
- `src/App.jsx`: roteamento para `/`, `/votacao` e `/resultado`, com o cabeçalho em todas as páginas.
- `src/App.css`: estilos responsivos dos cards, grades e placar.
- `src/main.jsx`, `index.html`, `package.json` e `vite.config.js`: inicialização e configuração completa do Vite.

## Persistência dos votos

Os votos ficam no `localStorage` do navegador, usando a chave `fazenda2026:votos`. Na tela Resultado, o botão **Zerar votação** pede confirmação antes de apagar a contagem.

As imagens de referência da pasta `prints/` e os arquivos de `public/` foram mantidos.
